import { Camera, useCameraDevice, useCameraPermission, useLocationPermission, useMicrophonePermission } from "react-native-vision-camera";


export const getPermissions = () => {


}